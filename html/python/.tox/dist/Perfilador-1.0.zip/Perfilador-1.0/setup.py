from distutils.core import setup

setup(name='Perfilador',
      version='1.0',
      description='Python Classificator',
      author='Los chavos!',
      author_email='carlosgonzagular@gmail.com',
      url='https://github.com/juanunam/ciscoproyect'
     )